package com.glucoguide.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.speech.RecognizerIntent
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import android.content.ContentValues
import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import java.io.File
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null

    private val hcPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class)
    )

    private val voiceLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val text = res.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull() ?: ""
            runJs("window.onVoiceResult(" + JSONObject.quote(text) + ")")
        }

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val cb = filePathCallback ?: return@registerForActivityResult
            var uris: Array<Uri>? = null
            if (res.resultCode == RESULT_OK) {
                val picked = res.data?.data
                uris = when {
                    picked != null -> arrayOf(picked)
                    cameraUri != null -> arrayOf(cameraUri!!)
                    else -> null
                }
            }
            cb.onReceiveValue(uris)
            filePathCallback = null
            cameraUri = null
        }

    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* result handled by OS */ }

    private val hcPermLauncher =
        registerForActivityResult(PermissionController.createRequestPermissionResultContract()) { granted ->
            if (granted.isNotEmpty()) {
                readHealthData()
            } else {
                runJs("window.onNativeMessage('Health Connect permission was not granted')")
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage persistence
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true   // lets the local app call the AI API
        }
        webView.addJavascriptInterface(Bridge(), "Android")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                launchPhotoChooser()
                return true
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun launchPhotoChooser() {
        val gallery = Intent(Intent.ACTION_GET_CONTENT).setType("image/*")
        var camera: Intent? = null
        try {
            val dir = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "Photos").apply { mkdirs() }
            val photo = File(dir, "meal_" + System.currentTimeMillis() + ".jpg")
            cameraUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", photo)
            camera = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(android.provider.MediaStore.EXTRA_OUTPUT, cameraUri)
        } catch (_: Exception) {
            cameraUri = null
        }
        val chooser = Intent.createChooser(gallery, "Add a photo")
        if (camera != null && camera.resolveActivity(packageManager) != null) {
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(camera))
        }
        try {
            fileLauncher.launch(chooser)
        } catch (_: Exception) {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = null
        }
    }

    private fun runJs(js: String) {
        webView.post { webView.evaluateJavascript(js, null) }
    }

    private fun syncHealth() {
        val status = HealthConnectClient.getSdkStatus(this)
        if (status != HealthConnectClient.SDK_AVAILABLE) {
            runJs("window.onNativeMessage('Health Connect app is not available on this phone — install it from the Play Store')")
            return
        }
        val client = HealthConnectClient.getOrCreate(this)
        lifecycleScope.launch {
            try {
                val granted = client.permissionController.getGrantedPermissions()
                if (granted.containsAll(hcPermissions)) {
                    readHealthData()
                } else {
                    hcPermLauncher.launch(hcPermissions)
                }
            } catch (e: Exception) {
                runJs("window.onNativeMessage('Health Connect error: could not check permissions')")
            }
        }
    }

    private fun readHealthData() {
        val client = HealthConnectClient.getOrCreate(this)
        lifecycleScope.launch {
            try {
                val zone = ZoneId.systemDefault()
                val now = Instant.now()
                val dayStart = LocalDate.now().atStartOfDay(zone).toInstant()
                val result = JSONObject()

                // Today's aggregates (each guarded — partial permissions still work)
                try {
                    val agg = client.aggregate(
                        AggregateRequest(
                            metrics = setOf(
                                StepsRecord.COUNT_TOTAL,
                                DistanceRecord.DISTANCE_TOTAL,
                                TotalCaloriesBurnedRecord.ENERGY_TOTAL,
                                HeartRateRecord.BPM_AVG
                            ),
                            timeRangeFilter = TimeRangeFilter.between(dayStart, now)
                        )
                    )
                    result.put("steps", agg[StepsRecord.COUNT_TOTAL] ?: 0L)
                    result.put("distanceKm", agg[DistanceRecord.DISTANCE_TOTAL]?.inKilometers ?: 0.0)
                    result.put("calories", agg[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories ?: 0.0)
                    result.put("hrAvg", agg[HeartRateRecord.BPM_AVG] ?: 0L)
                } catch (_: Exception) { }

                // Last night's sleep (yesterday 6 PM -> now)
                try {
                    val sleepStart = LocalDate.now().minusDays(1).atStartOfDay(zone)
                        .plusHours(18).toInstant()
                    val sleepAgg = client.aggregate(
                        AggregateRequest(
                            metrics = setOf(SleepSessionRecord.SLEEP_DURATION_TOTAL),
                            timeRangeFilter = TimeRangeFilter.between(sleepStart, now)
                        )
                    )
                    result.put("sleepMin", sleepAgg[SleepSessionRecord.SLEEP_DURATION_TOTAL]?.toMinutes() ?: 0L)
                } catch (_: Exception) { }

                // Latest weight (90 days)
                try {
                    val w = client.readRecords(
                        ReadRecordsRequest(
                            recordType = WeightRecord::class,
                            timeRangeFilter = TimeRangeFilter.between(now.minus(90, ChronoUnit.DAYS), now),
                            ascendingOrder = false,
                            pageSize = 1
                        )
                    ).records.firstOrNull()
                    if (w != null) result.put("weightKg", w.weight.inKilograms)
                } catch (_: Exception) { }

                // Exercise sessions today
                try {
                    val sessions = client.readRecords(
                        ReadRecordsRequest(
                            recordType = ExerciseSessionRecord::class,
                            timeRangeFilter = TimeRangeFilter.between(dayStart, now)
                        )
                    ).records
                    result.put("exerciseCount", sessions.size)
                    result.put("exerciseMin", sessions.sumOf { Duration.between(it.startTime, it.endTime).toMinutes() })
                } catch (_: Exception) { }

                runJs("window.onHealthSynced(" + JSONObject.quote(result.toString()) + ")")
            } catch (e: Exception) {
                runJs("window.onNativeMessage('Could not read data from Health Connect')")
            }
        }
    }

    inner class Bridge {

        @JavascriptInterface
        fun startVoiceInput() {
            runOnUiThread {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Say e.g. \"sugar 145\" or \"walked 30 minutes\"")
                try {
                    voiceLauncher.launch(intent)
                } catch (_: Exception) {
                    runJs("window.onNativeMessage('Voice recognition is not available on this phone')")
                }
            }
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            if (Build.VERSION.SDK_INT >= 33) {
                runOnUiThread { notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            }
        }

        @JavascriptInterface
        fun scheduleReminder(id: Int, hour: Int, minute: Int, title: String, message: String) {
            Reminders.schedule(this@MainActivity, id, hour, minute, title, message)
        }

        @JavascriptInterface
        fun cancelReminder(id: Int) {
            Reminders.cancel(this@MainActivity, id)
        }

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(send, "Share summary"))
            }
        }

        @JavascriptInterface
        fun syncHealthConnectSteps() {
            runOnUiThread { syncHealth() }
        }

        @JavascriptInterface
        fun syncHealthConnect() {
            runOnUiThread { syncHealth() }
        }

        @JavascriptInterface
        fun printPage() {
            runOnUiThread {
                try {
                    val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val adapter = webView.createPrintDocumentAdapter("GlucoGuide-Report")
                    pm.print("GlucoGuide Report", adapter, PrintAttributes.Builder().build())
                } catch (_: Exception) {
                    runJs("window.onNativeMessage('Printing is not available on this phone')")
                }
            }
        }

        @JavascriptInterface
        fun saveFile(name: String, mime: String, base64: String) {
            runOnUiThread {
                try {
                    val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
                    if (Build.VERSION.SDK_INT >= 29) {
                        val values = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, name)
                            put(MediaStore.Downloads.MIME_TYPE, mime)
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        if (uri != null) {
                            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                            values.clear()
                            values.put(MediaStore.Downloads.IS_PENDING, 0)
                            contentResolver.update(uri, values, null, null)
                            runJs("window.onNativeMessage(" + JSONObject.quote("Saved to Downloads: $name") + ")")
                        } else {
                            shareBytes(name, mime, bytes)
                        }
                    } else {
                        shareBytes(name, mime, bytes)
                    }
                } catch (_: Exception) {
                    runJs("window.onNativeMessage('Could not save the file')")
                }
            }
        }
    }

    private fun shareBytes(name: String, mime: String, bytes: ByteArray) {
        try {
            val dir = File(getExternalFilesDir(null), "Exports").apply { mkdirs() }
            val f = File(dir, name)
            f.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val send = Intent(Intent.ACTION_SEND).setType(mime)
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Save or share $name"))
        } catch (_: Exception) {
            runJs("window.onNativeMessage('Could not save the file')")
        }
    }
}
